// pages/enjoy/enjoy.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputVal:'',
    msgData:[   
    ]     
  },

  onLoad: function () {
    var that = this;
      wx.getStorage({
        key: 'val',
        success: function (res) {
          console.log(res.data);
          that.setData({
            msgData:res.data
          })
         },
        fail: function (res) {
          console.log('read fail');
         },
      })
  },
  
  addMsg(){
   // console.log(this.data.inputVal);
    var list = this.data.msgData;
    list.push({
      msg: this.data.inputVal
    });
    this.setData({
      msgData:list,
      inputVal:''
    })
  
    wx.setStorage({
      key: 'val',
      data: list,

      success: function () {
        console.log('success')
      },
      fail: function () {
        console.log('fail')
      }

    })
  },
  changeInputVal(ev){
    this.setData({
      inputVal:ev.detail.value
    });
  },
  delmsg(ev){
    var n=ev.target.dataset.index;
    var list =this.data.msgData;
    list.splice(n,1);
    this.setData({
      msgData:list
    });
   
    wx.setStorage({
      key: 'val',
      data: list,

      success: function () {
        console.log('success')
      },
      fail: function () {
        console.log('fail')
      }

    })
  },
  // test: function () {
  //   var value = this.data.msgData;
  //   wx.setStorage({
  //     key: 'enjoy',
  //     data: 'value',

  //     success:function(){
  //       console.log('success')
  //     },
  //     fail:function(){
  //       console.log('fail')
  //     }

  //   })
  // },



  // onLoad:function(){
  //   var that = this,
  //     wx.getStorage({//获取本地缓存
  //       key: "testNum",
  //       success: function (res) {
  //         that.setData({
  //           testnum: res.data
  //         });
  //       },

  
})