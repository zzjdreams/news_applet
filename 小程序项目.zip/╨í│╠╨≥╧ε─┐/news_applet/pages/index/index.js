//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    newsData:[],
    loadover:false,
    page:1
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },


  shizhen() {
    wx.navigateTo({
      url: '../enjoy/enjoy',
    })
  },

  lower(e) {
    var that = this;
    if(that.data.loadover) return;
    that.setData({
      page:that.data.page+1
    })
    wx.request({
      url: 'http://10.52.36.69:8888/api/news/list?page=' + that.data.page,
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        if(!res.data.length){
          that.setData({
            loadover:true
          })
        }else{
          if(res.data.length < 5){
            that.setData({
              loadover:true
            })
          }
          that.setData({
            newsData:
            that.data.newsData.concat(res.data)
          })
        }
      }
    })
  },
  //进入新闻详情页
  onNewTap: function(event){
    var id = event.currentTarget.dataset.idx;
    wx.navigateTo({
      url: '../news/news?id='+id,
    })
  },
  onLoad:function(){
    var that = this;
    wx.request({
      url: 'http://10.52.36.69:8888/api/news/list',
      header:{
        'contene-type':'application/json'
      },
      success(res){
        if(!res.data.length) return;
        that.setData({
          newsData:res.data
        })
      }
    })
  }
})