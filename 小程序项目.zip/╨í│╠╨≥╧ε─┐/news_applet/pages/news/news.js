// pages/news.js
var WxParse = require
  ('../../utils/wxParse/wxParse.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    news:{}    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id; 
    var that = this;
    wx.request({
      url: 'http://localhost:8888/api/news?id='+id,  
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
       if(!res.data){
         wx.navigateTo({
           url: '../news/list',
         })
       }else {
         that.setData({
           news:res.data
         });
         WxParse.wxParse('article','html',that.data.news.content,that,5);
       }
      }
    })   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(this);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("pull")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    wx.showLoading({
      title: '正在加载',
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;   
    var id = that.data.news.id;
    return{
      title:that.data.title,
      path: `pages/news/news?id=${id}`,
      imageUrl: that.data.news.pic_img ? that.data.news.pic_img : "../../images/logo.png"
    }
  }
})